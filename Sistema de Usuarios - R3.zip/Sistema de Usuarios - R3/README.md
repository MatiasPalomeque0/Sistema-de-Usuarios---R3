# Sistema de Usuarios - R3

Trabajo práctico con React + TypeScript, Express, API REST y MySQL.

## Estructura

```text
Sistema de Usuarios - R3/
├── client/       Frontend React + TypeScript
├── server/       API Express + TypeScript
└── database/     Esquema SQL de MySQL
```

## Requisitos

- Node.js y npm.
- MySQL Server.
- Crear la base ejecutando [`database/schema.sql`](database/schema.sql).

## Configurar el backend

Desde `server/`, copiar `.env.example` como `.env` y completar la contraseña de MySQL:

```bash
npm install
npm run dev
```

La API queda disponible en `http://localhost:4000`.

## Ejecutar el frontend

Desde `client/`:

```bash
npm install
npm run dev
```

La aplicación queda disponible en `http://localhost:5173`.

## Dos sistemas solicitados

### Sistema con React Router

- `/router/login`
- `/router/register`
- `/router/dashboard`

La navegación se realiza con rutas reales y `ProtectedRoute` impide acceder al panel sin una sesión válida.

### Sistema con useState

- `/state`

La pantalla se mantiene en la misma ruta y el estado `view` decide si se muestra login, registro o dashboard.

## Persistencia y protección

- Los usuarios se guardan en MySQL.
- Las contraseñas se almacenan con `bcrypt`, nunca en texto plano.
- La API entrega un token JWT con vencimiento.
- `localStorage` conserva únicamente el token para mantener la sesión.
- Las consultas SQL utilizan parámetros para evitar inyección.
- El endpoint de usuarios requiere el header `Authorization: Bearer <token>`.
