import { useCallback, useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { getCurrentUser, getUsers as requestUsers, loginUser, registerUser, TOKEN_STORAGE_KEY } from '../api/api';
import type { User } from '../types/user';
import { AuthContext } from './auth-context';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(TOKEN_STORAGE_KEY));
  const [isLoading, setIsLoading] = useState(() => Boolean(localStorage.getItem(TOKEN_STORAGE_KEY)));

  // Se recupera solo el token persistido y se valida contra la API. Nunca se
  // guarda la contraseña en localStorage.
  useEffect(() => {
    if (!token) return;

    getCurrentUser(token)
      .then(({ user: currentUser }) => setUser(currentUser))
      .catch(() => {
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        setToken(null);
        setUser(null);
      })
      .finally(() => setIsLoading(false));
  }, [token]);

  const saveSession = (nextToken: string, nextUser: User) => {
    localStorage.setItem(TOKEN_STORAGE_KEY, nextToken);
    setToken(nextToken);
    setUser(nextUser);
  };

  const login = async (email: string, password: string) => {
    const response = await loginUser({ email, password });
    saveSession(response.token, response.user);
  };

  const register = async (name: string, email: string, password: string) => {
    const response = await registerUser({ name, email, password });
    saveSession(response.token, response.user);
  };

  const logout = () => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    setToken(null);
    setUser(null);
  };

  const getUsers = useCallback(async () => {
    if (!token) return [];
    const response = await requestUsers(token);
    return response.users;
  }, [token]);

  return <AuthContext.Provider value={{ user, token, isLoading, login, register, logout, getUsers }}>{children}</AuthContext.Provider>;
}
