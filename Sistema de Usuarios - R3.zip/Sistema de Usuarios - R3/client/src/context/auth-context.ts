import { createContext } from 'react';
import type { User } from '../types/user';

export interface AuthContextValue {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  getUsers: () => Promise<User[]>;
}

export const AuthContext = createContext<AuthContextValue | undefined>(undefined);
