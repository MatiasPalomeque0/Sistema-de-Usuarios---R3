import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from './components/ProtectedRoute';
import { AuthProvider } from './context/AuthContext';
import { LandingPage } from './pages/LandingPage';
import { RouterDashboardPage } from './pages/RouterDashboardPage';
import { RouterLoginPage } from './pages/RouterLoginPage';
import { RouterRegisterPage } from './pages/RouterRegisterPage';
import { StateSystemPage } from './pages/StateSystemPage';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/router/login" element={<RouterLoginPage />} />
          <Route path="/router/register" element={<RouterRegisterPage />} />
          <Route path="/router/dashboard" element={<ProtectedRoute><RouterDashboardPage /></ProtectedRoute>} />
          <Route path="/state" element={<StateSystemPage />} />
          <Route path="*" element={<LandingPage />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
