import { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import type { User } from '../types/user';

export function UserDashboard({ onLogout }: { onLogout: () => void }) {
  const { user, getUsers } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    getUsers().then(setUsers).catch((loadError) => {
      setError(loadError instanceof Error ? loadError.message : 'No se pudieron cargar los usuarios.');
    });
  }, [getUsers]);

  if (!user) return null;

  return (
    <section className="dashboard-panel">
      <div className="dashboard-header">
        <div><p className="eyebrow">Sesión protegida</p><h1>Hola, {user.name}</h1><p>{user.email}</p></div>
        <button className="secondary-button" type="button" onClick={onLogout}>Cerrar sesión</button>
      </div>
      <div className="stats-grid">
        <div className="stat-card"><strong>{users.length}</strong><span>usuarios registrados</span></div>
        <div className="stat-card"><strong>SQL</strong><span>persistencia activa</span></div>
        <div className="stat-card"><strong>JWT</strong><span>sesión protegida</span></div>
      </div>
      {error ? <p className="form-error" role="alert">{error}</p> : <div className="user-list"><h2>Usuarios de la base de datos</h2>{users.map((listedUser) => <div className="user-row" key={listedUser.id}><span>{listedUser.name}</span><small>{listedUser.email}</small></div>)}</div>}
    </section>
  );
}
