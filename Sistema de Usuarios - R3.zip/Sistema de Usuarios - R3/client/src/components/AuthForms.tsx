import { useState } from 'react';
import type { FormEvent } from 'react';
import { useForm } from '../hooks/useForm';

interface LoginFormProps {
  onSubmit: (email: string, password: string) => Promise<void>;
  onSwitchToRegister: () => void;
}

interface RegisterFormProps {
  onSubmit: (name: string, email: string, password: string) => Promise<void>;
  onSwitchToLogin: () => void;
}

interface LoginFields { email: string; password: string; }
interface RegisterFields extends LoginFields { name: string; }

export function LoginForm({ onSubmit, onSwitchToRegister }: LoginFormProps) {
  const { values, handleChange } = useForm<LoginFields>({ email: '', password: '' });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setIsSubmitting(true);
    try { await onSubmit(values.email, values.password); }
    catch (submissionError) { setError(submissionError instanceof Error ? submissionError.message : 'No se pudo iniciar sesión.'); }
    finally { setIsSubmitting(false); }
  };

  return (
    <form className="auth-form" onSubmit={handleFormSubmit}>
      <label htmlFor="login-email">Email</label>
      <input id="login-email" name="email" type="email" value={values.email} onChange={handleChange} required />
      <label htmlFor="login-password">Contraseña</label>
      <input id="login-password" name="password" type="password" value={values.password} onChange={handleChange} required minLength={8} />
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="primary-button" type="submit" disabled={isSubmitting}>{isSubmitting ? 'Ingresando...' : 'Iniciar sesión'}</button>
      <button className="text-button" type="button" onClick={onSwitchToRegister}>Crear una cuenta</button>
    </form>
  );
}

export function RegisterForm({ onSubmit, onSwitchToLogin }: RegisterFormProps) {
  const { values, handleChange } = useForm<RegisterFields>({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setIsSubmitting(true);
    try { await onSubmit(values.name, values.email, values.password); }
    catch (submissionError) { setError(submissionError instanceof Error ? submissionError.message : 'No se pudo registrar el usuario.'); }
    finally { setIsSubmitting(false); }
  };

  return (
    <form className="auth-form" onSubmit={handleFormSubmit}>
      <label htmlFor="register-name">Nombre completo</label>
      <input id="register-name" name="name" type="text" value={values.name} onChange={handleChange} required />
      <label htmlFor="register-email">Email</label>
      <input id="register-email" name="email" type="email" value={values.email} onChange={handleChange} required />
      <label htmlFor="register-password">Contraseña</label>
      <input id="register-password" name="password" type="password" value={values.password} onChange={handleChange} required minLength={8} />
      <p className="field-help">Usá al menos 8 caracteres.</p>
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="primary-button" type="submit" disabled={isSubmitting}>{isSubmitting ? 'Registrando...' : 'Registrarme'}</button>
      <button className="text-button" type="button" onClick={onSwitchToLogin}>Ya tengo una cuenta</button>
    </form>
  );
}
