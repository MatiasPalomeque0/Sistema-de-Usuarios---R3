import { useState } from 'react';
import { LoginForm, RegisterForm } from '../components/AuthForms';
import { UserDashboard } from '../components/UserDashboard';
import { useAuth } from '../hooks/useAuth';

type StateView = 'login' | 'register' | 'dashboard';

export function StateSystemPage() {
  const { user, isLoading, login, register, logout } = useAuth();
  const [view, setView] = useState<StateView>('login');

  if (isLoading) return <div className="loading-state">Validando sesión...</div>;
  if (user) return <UserDashboard onLogout={() => { logout(); setView('login'); }} />;

  return <main className="auth-layout"><section className="auth-card"><p className="eyebrow">useState · Sistema independiente</p><h1>{view === 'login' ? 'Iniciar sesión' : 'Crear usuario'}</h1><p className="page-copy">En esta versión, la pantalla actual se controla con el estado `view`.</p>{view === 'login' ? <LoginForm onSubmit={login} onSwitchToRegister={() => setView('register')} /> : <RegisterForm onSubmit={register} onSwitchToLogin={() => setView('login')} />}<button className="text-button" type="button" onClick={() => setView(view === 'login' ? 'register' : 'login')}>Cambiar de pantalla con useState</button></section></main>;
}
