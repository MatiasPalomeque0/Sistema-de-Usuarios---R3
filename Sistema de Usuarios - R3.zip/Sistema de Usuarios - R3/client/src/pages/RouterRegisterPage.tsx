import { Link, useNavigate } from 'react-router-dom';
import { RegisterForm } from '../components/AuthForms';
import { useAuth } from '../hooks/useAuth';

export function RouterRegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  return <main className="auth-layout"><section className="auth-card"><p className="eyebrow">React Router · Registro</p><h1>Crear usuario</h1><p className="page-copy">Los datos se validan en la API y la contraseña se guarda hasheada.</p><RegisterForm onSubmit={async (name, email, password) => { await register(name, email, password); navigate('/router/dashboard'); }} onSwitchToLogin={() => navigate('/router/login')} /><Link className="back-link" to="/">← Volver a elegir sistema</Link></section></main>;
}
