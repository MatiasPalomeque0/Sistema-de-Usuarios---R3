import { Link, useNavigate } from 'react-router-dom';
import { LoginForm } from '../components/AuthForms';
import { useAuth } from '../hooks/useAuth';

export function RouterLoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  return <main className="auth-layout"><section className="auth-card"><p className="eyebrow">React Router · Acceso</p><h1>Iniciar sesión</h1><p className="page-copy">Ingresá para consultar los usuarios almacenados en MySQL.</p><LoginForm onSubmit={async (email, password) => { await login(email, password); navigate('/router/dashboard'); }} onSwitchToRegister={() => navigate('/router/register')} /><Link className="back-link" to="/">← Volver a elegir sistema</Link></section></main>;
}
