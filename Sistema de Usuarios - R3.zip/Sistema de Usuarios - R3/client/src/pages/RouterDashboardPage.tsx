import { useNavigate } from 'react-router-dom';
import { UserDashboard } from '../components/UserDashboard';
import { useAuth } from '../hooks/useAuth';

export function RouterDashboardPage() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  return <UserDashboard onLogout={() => { logout(); navigate('/router/login'); }} />;
}
