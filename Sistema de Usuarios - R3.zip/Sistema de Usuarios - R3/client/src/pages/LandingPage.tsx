import { Link } from 'react-router-dom';

export function LandingPage() {
  return (
    <main className="landing-page">
      <p className="eyebrow">Trabajo práctico · R3</p>
      <h1>Sistema de usuarios</h1>
      <p className="lead">Dos formas de resolver la navegación en React conectadas a una API y una base de datos MySQL.</p>
      <div className="system-grid">
        <Link className="system-card" to="/router/login"><span className="system-number">01</span><h2>Versión con React Router</h2><p>Cada pantalla tiene una ruta real y las rutas protegidas requieren una sesión válida.</p><strong>Ingresar →</strong></Link>
        <Link className="system-card" to="/state"><span className="system-number">02</span><h2>Versión con useState</h2><p>La navegación interna se controla con un estado de React dentro de una única página.</p><strong>Ingresar →</strong></Link>
      </div>
    </main>
  );
}
