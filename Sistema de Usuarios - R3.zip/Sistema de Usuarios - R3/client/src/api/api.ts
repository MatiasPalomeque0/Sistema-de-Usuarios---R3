import type { AuthResponse, User } from '../types/user';

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:4000/api';

export const TOKEN_STORAGE_KEY = 'sistema-usuarios-r3-token';

interface ApiErrorResponse {
  message?: string;
}

async function request<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  const data = (await response.json().catch(() => ({}))) as T & ApiErrorResponse;
  if (!response.ok) {
    throw new Error(data.message ?? 'Ocurrió un error al comunicarse con la API.');
  }
  return data;
}

export function registerUser(payload: { name: string; email: string; password: string }): Promise<AuthResponse> {
  return request<AuthResponse>('/auth/register', { method: 'POST', body: JSON.stringify(payload) });
}

export function loginUser(payload: { email: string; password: string }): Promise<AuthResponse> {
  return request<AuthResponse>('/auth/login', { method: 'POST', body: JSON.stringify(payload) });
}

export function getCurrentUser(token: string): Promise<{ user: User }> {
  return request<{ user: User }>('/users/me', {}, token);
}

export function getUsers(token: string): Promise<{ users: User[] }> {
  return request<{ users: User[] }>('/users', {}, token);
}
