import { useState } from 'react';
import type { ChangeEvent } from 'react';

export function useForm<T extends object>(initialValues: T) {
  const [values, setValues] = useState<T>(initialValues);

  const handleChange = (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = event.target;
    setValues((currentValues) => ({ ...currentValues, [name]: value } as T));
  };

  const reset = () => setValues(initialValues);

  return { values, handleChange, reset };
}
