import cors from 'cors';
import express from 'express';
import { env } from './config/env.js';
import { authRouter } from './routes/authRoutes.js';
import { userRouter } from './routes/userRoutes.js';

const app = express();

app.use(cors({ origin: env.clientOrigin }));
app.use(express.json({ limit: '20kb' }));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'sistema-usuarios-r3' });
});

app.use('/api/auth', authRouter);
app.use('/api/users', userRouter);

app.use((_req, res) => {
  res.status(404).json({ message: 'Recurso no encontrado.' });
});

app.listen(env.port, () => {
  console.log(`API disponible en http://localhost:${env.port}`);
});
