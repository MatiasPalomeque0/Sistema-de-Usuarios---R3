import type { PublicUser } from '../types/user.js';

export function toPublicUser(user: { id: number; name: string; email: string; created_at: Date }): PublicUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    createdAt: user.created_at.toISOString(),
  };
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
