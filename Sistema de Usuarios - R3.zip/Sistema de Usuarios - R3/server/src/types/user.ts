import type { RowDataPacket } from 'mysql2';

export interface UserRow extends RowDataPacket {
  id: number;
  name: string;
  email: string;
  password_hash: string;
  created_at: Date;
}

export interface PublicUserRow extends RowDataPacket {
  id: number;
  name: string;
  email: string;
  created_at: Date;
}

export interface PublicUser {
  id: number;
  name: string;
  email: string;
  createdAt: string;
}

export interface AuthenticatedRequest {
  user?: PublicUser;
}
