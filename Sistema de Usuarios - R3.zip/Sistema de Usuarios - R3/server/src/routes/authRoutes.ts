import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { ResultSetHeader } from 'mysql2';
import { pool } from '../config/database.js';
import { env } from '../config/env.js';
import type { UserRow } from '../types/user.js';
import { isValidEmail, toPublicUser } from '../utils/userUtils.js';

export const authRouter = Router();

function createToken(userId: number): string {
  return jwt.sign({}, env.jwtSecret, { subject: String(userId), expiresIn: '2h' });
}

authRouter.post('/register', async (req, res) => {
  const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';

  if (!name || !isValidEmail(email) || password.length < 8) {
    res.status(400).json({ message: 'Nombre, email válido y contraseña de 8 caracteres son obligatorios.' });
    return;
  }

  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const [result] = await pool.execute<ResultSetHeader>(
      'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)',
      [name, email, passwordHash],
    );
    const [rows] = await pool.execute<UserRow[]>('SELECT * FROM users WHERE id = ?', [result.insertId]);
    const user = rows[0];

    res.status(201).json({ token: createToken(user.id), user: toPublicUser(user) });
  } catch (error: unknown) {
    if (typeof error === 'object' && error !== null && 'code' in error && error.code === 'ER_DUP_ENTRY') {
      res.status(409).json({ message: 'Ya existe un usuario con ese email.' });
      return;
    }
    res.status(500).json({ message: 'No se pudo registrar el usuario.' });
  }
});

authRouter.post('/login', async (req, res) => {
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';

  if (!email || !password) {
    res.status(400).json({ message: 'Email y contraseña son obligatorios.' });
    return;
  }

  try {
    const [rows] = await pool.execute<UserRow[]>('SELECT * FROM users WHERE email = ?', [email]);
    const user = rows[0];
    const passwordMatches = user ? await bcrypt.compare(password, user.password_hash) : false;

    if (!user || !passwordMatches) {
      res.status(401).json({ message: 'Email o contraseña incorrectos.' });
      return;
    }

    res.json({ token: createToken(user.id), user: toPublicUser(user) });
  } catch {
    res.status(500).json({ message: 'No se pudo iniciar sesión.' });
  }
});
