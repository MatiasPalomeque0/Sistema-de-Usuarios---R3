import { Router } from 'express';
import { pool } from '../config/database.js';
import { requireAuth } from '../middleware/authMiddleware.js';
import type { PublicUserRow, UserRow } from '../types/user.js';
import { toPublicUser } from '../utils/userUtils.js';

export const userRouter = Router();
userRouter.use(requireAuth);

userRouter.get('/me', async (req, res) => {
  const userId = (req as typeof req & { user?: { id: number } }).user?.id;

  if (!userId) {
    res.status(401).json({ message: 'Sesión inválida.' });
    return;
  }

  try {
    const [rows] = await pool.execute<UserRow[]>('SELECT * FROM users WHERE id = ?', [userId]);
    const user = rows[0];
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }
    res.json({ user: toPublicUser(user) });
  } catch {
    res.status(500).json({ message: 'No se pudo obtener el usuario.' });
  }
});

userRouter.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.execute<PublicUserRow[]>(
      'SELECT id, name, email, created_at FROM users ORDER BY created_at DESC',
    );
    res.json({ users: rows.map(toPublicUser) });
  } catch {
    res.status(500).json({ message: 'No se pudieron obtener los usuarios.' });
  }
});
