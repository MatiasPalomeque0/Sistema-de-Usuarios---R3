import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import type { AuthenticatedRequest, PublicUser } from '../types/user.js';

interface TokenPayload {
  sub: string;
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.header('Authorization');
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : undefined;

  if (!token) {
    res.status(401).json({ message: 'Se requiere autenticación.' });
    return;
  }

  try {
    const payload = jwt.verify(token, env.jwtSecret) as TokenPayload;
    const requestWithUser = req as Request & AuthenticatedRequest;
    requestWithUser.user = {
      id: Number(payload.sub),
      name: '',
      email: '',
      createdAt: '',
    } satisfies PublicUser;
    next();
  } catch {
    res.status(401).json({ message: 'La sesión no es válida o expiró.' });
  }
}
